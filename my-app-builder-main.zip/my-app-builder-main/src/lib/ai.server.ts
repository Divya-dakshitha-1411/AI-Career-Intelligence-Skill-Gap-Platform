import { createOpenAI } from "@ai-sdk/openai";

export const MODEL = "openai/gpt-6-astra";

export function createProvider() {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured.");
  return createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });
}

export const responsesOptions = {
  openai: {
    forceReasoning: true,
    reasoningEffort: "low",
    reasoningSummary: "auto",
    store: false,
    include: ["reasoning.encrypted_content"],
  },
} as const;

export function friendlyAiError(e: unknown): string {
  const status = (e as { statusCode?: number })?.statusCode;
  if (status === 429) return "The AI is busy right now. Please wait a moment and try again.";
  if (status === 402 || status === 403)
    return "AI credits are used up for this workspace. Please add credits and try again.";
  return "The AI request failed. Please try again.";
}
