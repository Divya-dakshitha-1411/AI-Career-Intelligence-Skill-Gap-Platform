import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { reportSchema, type ChatMsg } from "./career.schema";

export const analyzeResume = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ text: z.string().min(50).max(40000) }).parse(d))
  .handler(async ({ data }) => {
    const { streamText, Output } = await import("ai");
    const { createProvider, MODEL, responsesOptions, friendlyAiError } = await import("./ai.server");
    const cleaned = data.text.replace(/\s+/g, " ").trim();
    try {
      const result = streamText({
        model: createProvider().responses(MODEL),
        instructions:
          "You are a career intelligence engine for students, fresh graduates and professionals (focus on India and global entry-level market). Analyze the resume text. Extract information only from the resume (use empty arrays / 'Not found' when missing; never invent). Infer skills implied by projects. Compute a realistic career readiness score 0-100 with a 5-part breakdown (Technical skills, Projects, Experience, Certifications, Resume quality). Recommend exactly ONE best-fit career. Give skill gap vs that career's industry requirements, a 4-phase roadmap, 4 portfolio projects (beginner to advanced), 5 matching job roles with match %, and 8 real, well-known learning resources with real URLs (prefer free: freeCodeCamp, Coursera, YouTube channels, official docs, Kaggle, NPTEL).",
        messages: [{ role: "user", content: `RESUME:\n${cleaned}` }],
        output: Output.object({ schema: reportSchema }),
        providerOptions: responsesOptions,
      });
      const out = await result.output;
      return { ok: true as const, report: out };
    } catch (e) {
      console.error(e);
      return { ok: false as const, error: friendlyAiError(e) };
    }
  });

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z
      .object({
        context: z.string().max(20000),
        messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(4000) })).max(30),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const { streamText } = await import("ai");
    const { createProvider, MODEL, responsesOptions, friendlyAiError } = await import("./ai.server");
    try {
      const result = streamText({
        model: createProvider().responses(MODEL),
        instructions: `You are a friendly, practical AI career mentor. Use the user's analysis below to give specific, actionable advice. Keep answers concise (under 200 words) with short bullet lists when helpful. Use plain text with simple "-" bullets.\n\nUSER ANALYSIS:\n${data.context || "No resume analyzed yet."}`,
        messages: data.messages as ChatMsg[],
        providerOptions: responsesOptions,
      });
      return { ok: true as const, text: await result.text };
    } catch (e) {
      console.error(e);
      return { ok: false as const, error: friendlyAiError(e) };
    }
  });
