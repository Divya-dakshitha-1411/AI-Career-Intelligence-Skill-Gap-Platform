import { z } from "zod";

const s = z.string();
const arr = z.array(z.string());

export const reportSchema = z.object({
  profile: z.object({
    name: s,
    userType: z.enum(["Student", "Fresh Graduate", "Working Professional"]),
    education: s,
    degree: s,
    branch: s,
    programmingLanguages: arr,
    technicalSkills: arr,
    softSkills: arr,
    projects: arr,
    internships: arr,
    certifications: arr,
    experience: arr,
    achievements: arr,
    interests: arr,
  }),
  readiness: z.object({
    score: z.number(),
    summary: s,
    breakdown: z.array(z.object({ label: s, score: z.number() })),
    strengths: arr,
    improvements: arr,
  }),
  career: z.object({ title: s, matchPercent: z.number(), why: s, averageSalary: s, demand: s }),
  skillGap: z.object({
    matched: arr,
    missing: z.array(z.object({ skill: s, priority: z.enum(["High", "Medium", "Low"]), why: s })),
  }),
  roadmap: z.array(z.object({ phase: s, duration: s, goals: arr, topics: arr })),
  projects: z.array(
    z.object({ title: s, level: z.enum(["Beginner", "Intermediate", "Advanced"]), description: s, skills: arr }),
  ),
  jobs: z.array(z.object({ title: s, matchPercent: z.number(), level: s, requirements: arr, missing: arr })),
  resources: z.array(
    z.object({ title: s, provider: s, type: s, url: s, skill: s, free: z.boolean() }),
  ),
});

export type Report = z.infer<typeof reportSchema>;
export type ChatMsg = { role: "user" | "assistant"; content: string };
