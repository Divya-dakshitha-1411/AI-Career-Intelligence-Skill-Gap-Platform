import type { ChatMsg, Report } from "./career.schema";

type User = { name: string; email: string; hash: string };
type UserData = { report?: Report; fileName?: string; analyzedAt?: string; chat?: ChatMsg[] };

const USERS = "sp_users";
const SESSION = "sp_session";
const dataKey = (email: string) => `sp_data_${email}`;

async function hash(pw: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(pw));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
const users = (): User[] => JSON.parse(localStorage.getItem(USERS) || "[]");

export async function signUp(name: string, email: string, pw: string) {
  email = email.trim().toLowerCase();
  if (users().some((u) => u.email === email)) throw new Error("An account with this email already exists.");
  localStorage.setItem(USERS, JSON.stringify([...users(), { name: name.trim(), email, hash: await hash(pw) }]));
  localStorage.setItem(SESSION, email);
}
export async function logIn(email: string, pw: string) {
  email = email.trim().toLowerCase();
  const u = users().find((x) => x.email === email);
  if (!u || u.hash !== (await hash(pw))) throw new Error("Wrong email or password.");
  localStorage.setItem(SESSION, email);
}
export const logOut = () => localStorage.removeItem(SESSION);
export function currentUser() {
  const e = localStorage.getItem(SESSION);
  const u = users().find((x) => x.email === e);
  return u ? { name: u.name, email: u.email } : null;
}
export const loadData = (email: string): UserData => JSON.parse(localStorage.getItem(dataKey(email)) || "{}");
export const saveData = (email: string, d: UserData) =>
  localStorage.setItem(dataKey(email), JSON.stringify({ ...loadData(email), ...d }));
