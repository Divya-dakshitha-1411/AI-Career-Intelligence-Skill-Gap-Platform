import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink, FileUp, Loader2, LogOut, Send, Compass } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { analyzeResume, askAssistant } from "@/lib/career.functions";
import type { ChatMsg, Report } from "@/lib/career.schema";
import { currentUser, loadData, logOut, saveData } from "@/lib/store";
import { extractPdfText } from "@/lib/pdf";

export const Route = createFileRoute("/dashboard")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Dashboard — SkillPath AI" },
      { name: "description", content: "Your resume analysis, readiness score, career match, roadmap and AI mentor." },
      { property: "og:title", content: "Dashboard — SkillPath AI" },
      { property: "og:description", content: "Your personal career intelligence dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const nav = useNavigate();
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [report, setReport] = useState<Report | undefined>();
  const [fileName, setFileName] = useState<string>();
  const [stage, setStage] = useState<string | null>(null);
  const analyze = useServerFn(analyzeResume);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const u = currentUser();
    if (!u) return void nav({ to: "/" });
    setUser(u);
    const d = loadData(u.email);
    setReport(d.report);
    setFileName(d.fileName);
  }, [nav]);

  async function onFile(file?: File) {
    if (!file || !user) return;
    if (file.type !== "application/pdf") { toast.error("Please upload a PDF file."); return; }
    try {
      setStage("Reading your PDF…");
      const text = await extractPdfText(file);
      if (text.length < 50) throw new Error("Couldn't read text from this PDF. Is it a scanned image?");
      setStage("AI is analyzing your resume… (about 30–60 seconds)");
      const res = await analyze({ data: { text: text.slice(0, 40000) } });
      if (!res.ok) throw new Error(res.error);
      setReport(res.report);
      setFileName(file.name);
      saveData(user.email, { report: res.report, fileName: file.name, analyzedAt: new Date().toISOString(), chat: [] });
      toast.success("Analysis complete!");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setStage(null);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  if (!user) return null;
  return (
    <div className="min-h-screen">
      <header className="border-b bg-card">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <span className="font-display text-xl text-primary">SkillPath AI</span>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-muted-foreground sm:inline">Hi, {user.name}</span>
            <Button variant="ghost" size="sm" onClick={() => { logOut(); nav({ to: "/" }); }}>
              <LogOut className="h-4 w-4" /> Log out
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-6 px-5 py-8">
        <section className="flex flex-col gap-4 rounded-2xl bg-hero p-6 text-primary-foreground md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="font-display text-2xl md:text-3xl">{report ? "Your career intelligence" : "Start with your resume"}</h1>
            <p className="mt-1 text-sm text-primary-foreground/80">
              {stage ?? (fileName ? `Analyzed: ${fileName}` : "Upload a PDF resume to get your full analysis.")}
            </p>
          </div>
          <input ref={fileRef} type="file" accept="application/pdf" hidden onChange={(e) => onFile(e.target.files?.[0])} />
          <Button variant="secondary" disabled={!!stage} onClick={() => fileRef.current?.click()}>
            {stage ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileUp className="h-4 w-4" />}
            {report ? "Upload new resume" : "Upload resume (PDF)"}
          </Button>
        </section>

        {report ? <ReportView report={report} email={user.email} /> : !stage && <Empty />}
      </main>
    </div>
  );
}

function Empty() {
  return (
    <div className="rounded-2xl border border-dashed bg-card p-10 text-center">
      <Compass className="mx-auto h-10 w-10 text-primary" />
      <p className="mt-3 font-display text-lg">No analysis yet</p>
      <p className="text-sm text-muted-foreground">Your score, career match, skill gap, roadmap and more will appear here.</p>
    </div>
  );
}

function ReportView({ report: r, email }: { report: Report; email: string }) {
  return (
    <Tabs defaultValue="overview">
      <TabsList className="flex h-auto w-full flex-wrap justify-start">
        {["overview", "profile", "gap", "roadmap", "projects", "jobs", "resources", "assistant"].map((t) => (
          <TabsTrigger key={t} value={t} className="capitalize">
            {t === "gap" ? "Skill gap" : t === "assistant" ? "AI mentor" : t}
          </TabsTrigger>
        ))}
      </TabsList>

      <TabsContent value="overview" className="mt-5 grid gap-5 md:grid-cols-3">
        <Card className="flex flex-col items-center text-center">
          <p className="text-sm text-muted-foreground">Career readiness</p>
          <ScoreRing value={r.readiness.score} />
          <p className="mt-3 text-sm">{r.readiness.summary}</p>
        </Card>
        <Card className="md:col-span-2">
          <p className="text-sm text-muted-foreground">Your best-fit career</p>
          <div className="mt-1 flex flex-wrap items-baseline gap-3">
            <h2 className="font-display text-3xl text-primary">{r.career.title}</h2>
            <Badge>{Math.round(r.career.matchPercent)}% match</Badge>
          </div>
          <p className="mt-3 text-sm">{r.career.why}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 text-sm">
            <div className="rounded-xl bg-muted p-3"><b>Salary:</b> {r.career.averageSalary}</div>
            <div className="rounded-xl bg-muted p-3"><b>Demand:</b> {r.career.demand}</div>
          </div>
        </Card>
        <Card className="md:col-span-2">
          <h3 className="font-display text-lg">Score breakdown</h3>
          <div className="mt-3 space-y-3">
            {r.readiness.breakdown.map((b) => (
              <div key={b.label}>
                <div className="mb-1 flex justify-between text-sm"><span>{b.label}</span><span>{Math.round(b.score)}</span></div>
                <Progress value={b.score} />
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="font-display text-lg">Strengths</h3>
          <List items={r.readiness.strengths} />
          <h3 className="mt-4 font-display text-lg">Improve</h3>
          <List items={r.readiness.improvements} />
        </Card>
      </TabsContent>

      <TabsContent value="profile" className="mt-5 grid gap-5 md:grid-cols-2">
        <Card>
          <h3 className="font-display text-2xl">{r.profile.name}</h3>
          <Badge variant="secondary" className="mt-1">{r.profile.userType}</Badge>
          <dl className="mt-4 space-y-2 text-sm">
            <Row k="Education" v={r.profile.education} />
            <Row k="Degree" v={r.profile.degree} />
            <Row k="Branch" v={r.profile.branch} />
          </dl>
        </Card>
        <Card><Chips title="Programming languages" items={r.profile.programmingLanguages} /><Chips title="Technical skills" items={r.profile.technicalSkills} /><Chips title="Soft skills" items={r.profile.softSkills} /></Card>
        {([
          ["Projects", r.profile.projects], ["Internships", r.profile.internships], ["Work experience", r.profile.experience],
          ["Certifications", r.profile.certifications], ["Achievements", r.profile.achievements], ["Interests", r.profile.interests],
        ] as const).map(([t, items]) => (
          <Card key={t}><h3 className="font-display text-lg">{t}</h3><List items={[...items]} /></Card>
        ))}
      </TabsContent>

      <TabsContent value="gap" className="mt-5 grid gap-5 md:grid-cols-3">
        <Card><Chips title="Skills you have" items={r.skillGap.matched} /></Card>
        <Card className="md:col-span-2">
          <h3 className="font-display text-lg">Skills to learn for {r.career.title}</h3>
          <div className="mt-3 space-y-3">
            {r.skillGap.missing.map((m) => (
              <div key={m.skill} className="rounded-xl border p-3">
                <div className="flex items-center justify-between"><b>{m.skill}</b>
                  <Badge variant={m.priority === "High" ? "destructive" : "secondary"}>{m.priority}</Badge></div>
                <p className="mt-1 text-sm text-muted-foreground">{m.why}</p>
              </div>
            ))}
          </div>
        </Card>
      </TabsContent>

      <TabsContent value="roadmap" className="mt-5 space-y-4">
        {r.roadmap.map((p, i) => (
          <Card key={i} className="flex gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary font-bold text-primary-foreground">{i + 1}</div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2"><h3 className="font-display text-lg">{p.phase}</h3><Badge variant="outline">{p.duration}</Badge></div>
              <List items={p.goals} />
              <div className="mt-2 flex flex-wrap gap-1.5">{p.topics.map((t) => <Badge key={t} variant="secondary">{t}</Badge>)}</div>
            </div>
          </Card>
        ))}
      </TabsContent>

      <TabsContent value="projects" className="mt-5 grid gap-5 md:grid-cols-2">
        {r.projects.map((p) => (
          <Card key={p.title}>
            <Badge variant="outline">{p.level}</Badge>
            <h3 className="mt-2 font-display text-lg">{p.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{p.description}</p>
            <div className="mt-3 flex flex-wrap gap-1.5">{p.skills.map((s) => <Badge key={s} variant="secondary">{s}</Badge>)}</div>
          </Card>
        ))}
      </TabsContent>

      <TabsContent value="jobs" className="mt-5 grid gap-5 md:grid-cols-2">
        {[...r.jobs].sort((a, b) => b.matchPercent - a.matchPercent).map((j) => (
          <Card key={j.title}>
            <div className="flex items-start justify-between gap-2">
              <div><h3 className="font-display text-lg">{j.title}</h3><p className="text-sm text-muted-foreground">{j.level}</p></div>
              <Badge>{Math.round(j.matchPercent)}%</Badge>
            </div>
            <Progress value={j.matchPercent} className="mt-3" />
            <Chips title="Requirements" items={j.requirements} />
            {j.missing.length > 0 && <Chips title="You're missing" items={j.missing} />}
            <a className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary" target="_blank" rel="noreferrer"
              href={`https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(j.title)}`}>
              Search openings <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </Card>
        ))}
      </TabsContent>

      <TabsContent value="resources" className="mt-5 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {r.resources.map((x) => (
          <a key={x.url + x.title} href={x.url} target="_blank" rel="noreferrer" className="block rounded-2xl border bg-card p-5 transition hover:shadow-soft">
            <div className="flex gap-1.5"><Badge variant="secondary">{x.type}</Badge>{x.free && <Badge variant="outline">Free</Badge>}</div>
            <h3 className="mt-2 font-display text-lg">{x.title}</h3>
            <p className="text-sm text-muted-foreground">{x.provider} · {x.skill}</p>
          </a>
        ))}
      </TabsContent>

      <TabsContent value="assistant" className="mt-5">
        <Assistant report={r} email={email} />
      </TabsContent>
    </Tabs>
  );
}

function Assistant({ report, email }: { report: Report; email: string }) {
  const [msgs, setMsgs] = useState<ChatMsg[]>(() => loadData(email).chat ?? []);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const ask = useServerFn(askAssistant);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs, busy]);

  async function send(text: string) {
    if (!text.trim() || busy) return;
    const next = [...msgs, { role: "user" as const, content: text.trim() }];
    setMsgs(next); setInput(""); setBusy(true);
    const ctx = JSON.stringify({ profile: report.profile, readiness: report.readiness.score, career: report.career, skillGap: report.skillGap });
    const res = await ask({ data: { context: ctx, messages: next.slice(-20) } });
    setBusy(false);
    if (!res.ok) return void toast.error(res.error);
    const all = [...next, { role: "assistant" as const, content: res.text }];
    setMsgs(all); saveData(email, { chat: all });
  }

  const suggestions = ["How do I become job-ready in 3 months?", "What should I add to my resume?", "Which skill should I learn first?"];
  return (
    <Card className="flex h-[70vh] flex-col p-0">
      <div className="flex-1 space-y-3 overflow-y-auto p-5">
        {msgs.length === 0 && (
          <div className="text-center">
            <Compass className="mx-auto h-8 w-8 text-primary" />
            <p className="mt-2 font-display text-lg">Ask your career mentor</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {suggestions.map((s) => <Button key={s} variant="outline" size="sm" onClick={() => send(s)}>{s}</Button>)}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={m.role === "user" ? "ml-auto max-w-[80%] rounded-2xl bg-primary px-4 py-2 text-primary-foreground" : "max-w-[90%] whitespace-pre-wrap text-sm leading-relaxed"}>
            {m.content}
          </div>
        ))}
        {busy && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
        <div ref={end} />
      </div>
      <form className="flex gap-2 border-t p-3" onSubmit={(e) => { e.preventDefault(); send(input); }}>
        <Textarea value={input} onChange={(e) => setInput(e.target.value)} rows={1} placeholder="Ask anything about your career…" className="min-h-10 resize-none"
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }} />
        <Button size="icon" disabled={busy || !input.trim()} aria-label="Send"><Send className="h-4 w-4" /></Button>
      </form>
    </Card>
  );
}

function Card({ className = "", children }: { className?: string; children: React.ReactNode }) {
  return <div className={`rounded-2xl border bg-card p-5 ${className}`}>{children}</div>;
}
function List({ items }: { items: string[] }) {
  if (!items.length) return <p className="mt-2 text-sm text-muted-foreground">Not found in resume</p>;
  return <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{items.map((x, i) => <li key={i}>{x}</li>)}</ul>;
}
function Chips({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="mt-3 first:mt-0">
      <p className="mb-1.5 text-sm font-semibold">{title}</p>
      {items.length ? <div className="flex flex-wrap gap-1.5">{items.map((x) => <Badge key={x} variant="secondary">{x}</Badge>)}</div>
        : <p className="text-sm text-muted-foreground">None found</p>}
    </div>
  );
}
function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex gap-2"><dt className="w-24 shrink-0 text-muted-foreground">{k}</dt><dd>{v}</dd></div>;
}
function ScoreRing({ value }: { value: number }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  const c = 2 * Math.PI * 52;
  return (
    <svg viewBox="0 0 120 120" className="mt-3 h-36 w-36">
      <circle cx="60" cy="60" r="52" fill="none" strokeWidth="10" className="stroke-muted" />
      <circle cx="60" cy="60" r="52" fill="none" strokeWidth="10" strokeLinecap="round" className="stroke-primary"
        strokeDasharray={c} strokeDashoffset={c * (1 - v / 100)} transform="rotate(-90 60 60)" />
      <text x="60" y="68" textAnchor="middle" className="fill-foreground font-display text-3xl">{v}</text>
    </svg>
  );
}
