import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Compass, FileSearch, Map, Target } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { currentUser, logIn, signUp } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SkillPath AI — Career Intelligence & Skill-Gap Platform" },
      { name: "description", content: "Upload your resume, get a readiness score, your best-fit career, skill gaps and a learning roadmap." },
      { property: "og:title", content: "SkillPath AI — Career Intelligence" },
      { property: "og:description", content: "Understand your skills. Discover your career. Build your future." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: FileSearch, t: "Resume analysis", d: "AI reads your PDF and extracts skills, projects and experience." },
  { icon: Target, t: "Readiness score", d: "See how job-ready you are, with a clear breakdown." },
  { icon: Compass, t: "One best career", d: "A single, confident recommendation with your skill gap." },
  { icon: Map, t: "Roadmap & jobs", d: "Learning plan, projects, matched roles and free resources." },
];

function Landing() {
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (currentUser()) nav({ to: "/dashboard" });
  }, [nav]);

  async function submit(e: React.FormEvent<HTMLFormElement>, mode: "in" | "up") {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email"));
    const pw = String(f.get("password"));
    if (pw.length < 6) { toast.error("Password must be at least 6 characters."); return; }
    setBusy(true);
    try {
      if (mode === "up") await signUp(String(f.get("name")), email, pw);
      else await logIn(email, pw);
      nav({ to: "/dashboard" });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen">
      <section className="bg-hero text-primary-foreground">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-2 md:py-24">
          <div className="flex flex-col justify-center">
            <p className="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">SkillPath AI</p>
            <h1 className="font-display text-4xl leading-tight md:text-6xl">
              Understand your skills. Discover your career. Build your future.
            </h1>
            <p className="mt-5 max-w-md text-primary-foreground/80">
              Upload your resume and get an honest readiness score, the one career that fits you best, and a step-by-step plan to get there.
            </p>
          </div>
          <div className="rounded-2xl bg-card p-6 text-card-foreground shadow-soft">
            <Tabs defaultValue="up">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="up">Sign up</TabsTrigger>
                <TabsTrigger value="in">Log in</TabsTrigger>
              </TabsList>
              <TabsContent value="up">
                <form className="mt-4 space-y-4" onSubmit={(e) => submit(e, "up")}>
                  <Field name="name" label="Full name" />
                  <Field name="email" label="Email" type="email" />
                  <Field name="password" label="Password" type="password" />
                  <Button className="w-full" disabled={busy}>Create account</Button>
                </form>
              </TabsContent>
              <TabsContent value="in">
                <form className="mt-4 space-y-4" onSubmit={(e) => submit(e, "in")}>
                  <Field name="email" label="Email" type="email" />
                  <Field name="password" label="Password" type="password" />
                  <Button className="w-full" disabled={busy}>Log in</Button>
                </form>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-5 px-5 py-14 sm:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <div key={f.t} className="rounded-2xl border bg-card p-5">
            <f.icon className="mb-3 h-6 w-6 text-primary" />
            <h3 className="font-display text-lg">{f.t}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
          </div>
        ))}
      </section>
    </main>
  );
}

function Field({ name, label, type = "text" }: { name: string; label: string; type?: string }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} required />
    </div>
  );
}
